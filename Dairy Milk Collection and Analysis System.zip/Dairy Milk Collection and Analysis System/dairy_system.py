from datetime import datetime
import numpy as np
import matplotlib.pyplot as plt
from db_connection import get_connection
import mysql.connector

class DairySystem:
    def _execute_query(self, query, params=None, fetch=False):
        """
        Executes a query and returns the result if fetch is True.
        """
        try:
            with get_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(query, params)
                    if fetch:
                        return cur.fetchall()
                    conn.commit()
        except mysql.connector.Error as err:
            print(f"Error: {err}")
            return None if fetch else False
        return True

    # ================= FARMER MENU =================
    def farmer_menu(self):
        while True:
            print("\n--- Farmer Management ---")
            print("1. Add Farmer")
            print("2. View Farmers")
            print("3. Update Farmer")
            print("4. Back")

            ch = input("Enter choice: ")

            if ch == "1":
                self.add_farmer()
            elif ch == "2":
                self.view_farmers()
            elif ch == "3":
                self.update_farmer()
            elif ch == "4":
                break

    def add_farmer(self):
        farmer_id = input("Farmer ID: ")
        name = input("Name: ")
        village = input("Village: ")
        phone = input("Phone: ")

        if not phone.isdigit() or len(phone) != 10:
            print("Invalid phone number")
            return

        if self._execute_query("INSERT INTO farmers VALUES (%s,%s,%s,%s)", (farmer_id, name, village, phone)):
            print("Farmer added")

    def view_farmers(self):
        rows = self._execute_query("SELECT * FROM farmers", fetch=True)
        if rows:
            print("\nID | Name | Village | Phone")
            for r in rows:
                print(r[0], "|", r[1], "|", r[2], "|", r[3])

    def update_farmer(self):
        farmer_id = input("Farmer ID: ")
        if not self._execute_query("SELECT * FROM farmers WHERE farmer_id=%s", (farmer_id,), fetch=True):
            print("Farmer not found")
            return

        name = input("New Name: ")
        village = input("New Village: ")
        phone = input("New Phone: ")

        if not phone.isdigit() or len(phone) != 10:
            print("Invalid phone")
            return

        if self._execute_query("UPDATE farmers SET name=%s,village=%s,phone=%s WHERE farmer_id=%s", (name, village, phone, farmer_id)):
            print("Farmer updated")

    # ================= MILK =================
    def milk_menu(self):
        while True:
            print("\n--- Milk Collection ---")
            print("1. Add Milk Entry")
            print("2. View Milk Entries")
            print("3. Back")

            ch = input("Enter choice: ")

            if ch == "1":
                self.add_milk()
            elif ch == "2":
                self.view_milk()
            elif ch == "3":
                break

    def add_milk(self):
        farmer_id = input("Farmer ID: ")
        
        while True:
            date_str = input("Date (YYYY-MM-DD): ")
            try:
                date = datetime.strptime(date_str, "%Y-%m-%d").date()
                break
            except ValueError:
                print("Invalid date format. Please use YYYY-MM-DD.")

        try:
            qty = float(input("Quantity: "))
            fat = float(input("Fat: "))
        except ValueError:
            print("Invalid input for quantity or fat.")
            return

        if qty <= 0 or fat <= 0:
            print("Invalid values for quantity or fat.")
            return

        if not self._execute_query("SELECT farmer_id FROM farmers WHERE farmer_id=%s", (farmer_id,), fetch=True):
            print("Farmer does not exist")
            return

        amount = qty * fat * 10
        
        if self._execute_query("INSERT INTO milk_records (farmer_id,date,quantity,fat,amount) VALUES (%s,%s,%s,%s,%s)", (farmer_id, date, qty, fat, amount)):
            print("Milk entry added")

    def view_milk(self):
        rows = self._execute_query("SELECT * FROM milk_records", fetch=True)
        if rows:
            print("\nID | Farmer | Date | Qty | Fat | Amount")
            for r in rows:
                print(r[0], "|", r[1], "|", r[2], "|", r[3], "|", r[4], "|", r[5])

    # ================= NUMPY REPORTS =================
    def report_menu(self):
        while True:
            print("\n--- Reports ---")
            print("1. Average Milk (NumPy)")
            print("2. Average Fat (NumPy)")
            print("3. Back")

            ch = input("Enter choice: ")

            if ch == "1":
                self.avg_milk()
            elif ch == "2":
                self.avg_fat()
            elif ch == "3":
                break

    def avg_milk(self):
        data = self._execute_query("SELECT quantity FROM milk_records", fetch=True)
        if data:
            arr = np.array([x[0] for x in data])
            print("Average Milk:", np.mean(arr))

    def avg_fat(self):
        data = self._execute_query("SELECT fat FROM milk_records", fetch=True)
        if data:
            arr = np.array([x[0] for x in data])
            print("Average Fat:", np.mean(arr))

    # ================= VISUALIZATION =================
    def visualization_menu(self):
        while True:
            print("\n--- Visualization ---")
            print("1. Farmer-wise Milk Collection (Bar Chart)")
            print("2. Milk Quantity Distribution (Histogram)")
            print("3. Village-wise Milk Collection (Pie Chart)")
            print("4. Milk Collection Over Time (Line Chart)")
            print("5. Back")

            ch = input("Enter choice: ")

            if ch == "1":
                self.bar_chart()
            elif ch == "2":
                self.milk_quantity_histogram()
            elif ch == "3":
                self.milk_collection_by_village_pie_chart()
            elif ch == "4":
                self.milk_collection_over_time_line_chart()
            elif ch == "5":
                break

    def bar_chart(self):
        rows = self._execute_query("SELECT farmer_id, SUM(quantity) FROM milk_records GROUP BY farmer_id", fetch=True)
        if rows:
            farmers = [r[0] for r in rows]
            milk = [r[1] for r in rows]

            plt.bar(farmers, milk)
            plt.xlabel("Farmer ID")
            plt.ylabel("Total Milk")
            plt.title("Farmer-wise Milk Collection")
            plt.show()

    def milk_quantity_histogram(self):
        data = self._execute_query("SELECT quantity FROM milk_records", fetch=True)
        if data:
            quantities = [r[0] for r in data]
            plt.hist(quantities, bins=10, edgecolor='black')
            plt.xlabel("Milk Quantity")
            plt.ylabel("Frequency")
            plt.title("Distribution of Milk Quantity")
            plt.show()

    def milk_collection_by_village_pie_chart(self):
        query = """
            SELECT f.village, SUM(mr.quantity) 
            FROM milk_records mr
            JOIN farmers f ON mr.farmer_id = f.farmer_id
            GROUP BY f.village
        """
        rows = self._execute_query(query, fetch=True)
        if rows:
            villages = [r[0] for r in rows]
            milk = [r[1] for r in rows]

            plt.pie(milk, labels=villages, autopct='%1.1f%%', startangle=90)
            plt.title("Village-wise Milk Collection")
            plt.axis('equal')
            plt.show()

    def milk_collection_over_time_line_chart(self):
        query = "SELECT date, SUM(quantity) FROM milk_records GROUP BY date ORDER BY date"
        rows = self._execute_query(query, fetch=True)
        if rows:
            dates = [r[0] for r in rows]
            milk = [r[1] for r in rows]

            plt.plot(dates, milk, marker='o')
            plt.xlabel("Date")
            plt.ylabel("Total Milk")
            plt.title("Milk Collection Over Time")
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.show()