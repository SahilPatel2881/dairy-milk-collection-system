from dairy_system import DairySystem

def main():
    system = DairySystem()

    while True:
        print("\n==============================")
        print(" DAIRY MILK COLLECTION SYSTEM ")
        print("==============================")
        print("1. Farmer Management")
        print("2. Milk Collection")
        print("3. Reports & Analysis")
        print("4. Visualization")
        print("5. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            system.farmer_menu()
        elif choice == "2":
            system.milk_menu()
        elif choice == "3":
            system.report_menu()
        elif choice == "4":
            system.visualization_menu()
        elif choice == "5":
            break
        else:
            print("Invalid choice")

main()
